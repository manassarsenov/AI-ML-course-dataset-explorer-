M1C5 Manager <-> ML Engineer Discovery Lab - Student Case Pack

Contents:
- Cue_Cards/: 20 shared case cards. Both Manager and ML Engineer receive the same cue card.
- Role_Templates/ML_Engineer_Worksheet.docx: individual Engineer worksheet.
- Role_Templates/Manager_Role_Instructions.docx: Manager role guide with optional reasoning styles.

Use only the facts on each cue card. Missing information must be treated as unknown.
