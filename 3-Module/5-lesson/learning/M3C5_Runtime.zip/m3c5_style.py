import html, re
from IPython.display import display, HTML

def show_note(title, text):
    display(HTML('<section style="margin:1.2rem 0;padding:1rem;border:1px solid currentColor;border-radius:8px;font:inherit;line-height:1.5">'
        + '<strong style="display:block;margin-bottom:.4rem">'+html.escape(title)+'</strong>'
        + '<div style="white-space:pre-wrap;overflow-wrap:anywhere">'+html.escape(str(text))+'</div></section>'))

def show_text(title, text):
    show_note(title, text)

def show_table(title, meaning, frame, rename=None, max_height=None):
    shown=frame.rename(columns=rename or {})
    table=shown.to_html(index=False,escape=True,max_rows=None,max_cols=None,border=0)
    minimum = f';min-width:{len(shown.columns)*125}px' if len(shown.columns) > 4 else ''
    table=table.replace('<table ', '<table style="border-collapse:collapse;width:100%;font:inherit;text-align:left'+minimum+'" ')
    table=re.sub(r'<th(?: [^>]*)?>', '<th>', table)
    table=table.replace('<th>', '<th style="padding:.6rem;text-align:left !important;border-bottom:1px solid currentColor;white-space:normal;overflow-wrap:anywhere">')
    table=table.replace('<td>', '<td style="padding:.6rem;text-align:left !important;vertical-align:top;border-bottom:1px solid currentColor;white-space:normal;overflow-wrap:anywhere;max-width:30rem">')
    panel_style='max-width:100%;overflow:auto'
    panel_label=''
    if max_height is not None:
        panel_style+=f';max-height:{max_height}px'
        panel_label='<p style="margin:.4rem 0;font-size:.9em">'+html.escape(f'Full table: {len(shown)} rows. Scroll inside the table to read every row; focus the panel to use the keyboard.')+'</p>'
    display(HTML('<section style="margin:1.5rem 0;font:inherit;line-height:1.5">'
        + '<h3 style="font:inherit;font-weight:700;margin:0 0 .4rem">'+html.escape(title)+'</h3>'
        + '<p style="margin:0 0 .8rem">'+html.escape(meaning)+'</p>'
        + panel_label+'<div role="region" tabindex="0" aria-label="'+html.escape(title,quote=True)+'" style="'+panel_style+'">'+table+'</div></section>'))
