import hashlib, json, time, sys
from m3c5_style import show_note, show_text, show_table
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display, HTML
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import precision_score, recall_score, classification_report
from imblearn.over_sampling import RandomOverSampler, SMOTE
from sklearn.metrics import accuracy_score, f1_score
_SPLIT=json.loads(Path('_m3c5_runtime/M3_Split_Card.json').read_text(encoding='utf-8'))
_SHA='16320c9c1ec72448db59aa0a26a0b95401046bef5d02fd3aeb906448e3055e91'
_BASE_NUM=['SeniorCitizen','tenure','MonthlyCharges','TotalCharges']
_CAT=['gender','Partner','Dependents','PhoneService','MultipleLines','InternetService','OnlineSecurity','OnlineBackup','DeviceProtection','TechSupport','StreamingTV','StreamingMovies','Contract','PaperlessBilling','PaymentMethod']
_SERVICES=['PhoneService','InternetService','OnlineSecurity','OnlineBackup','DeviceProtection','TechSupport','StreamingTV','StreamingMovies']
_EXTRA=['charge_per_month','monthly_charge_x_tenure','tenure_years','num_services','charge_per_service']
def _service_count(df):
    out = pd.Series(0, index=df.index, dtype='int64')
    for col in _SERVICES:
        vals = df[col]
        if col == 'InternetService':
            allowed = {'DSL','Fiber optic','No'}
            found = set(vals.dropna().unique())
            assert found <= allowed, f'Unmapped InternetService value(s): {sorted(found-allowed)}'
            active = vals.isin(['DSL','Fiber optic'])
        else:
            allowed = {'Yes','No','No internet service','No phone service'}
            found = set(vals.dropna().unique())
            assert found <= allowed, f'Unmapped {col} value(s): {sorted(found-allowed)}'
            active = vals.eq('Yes')
        assert vals.notna().all(), f'Missing service value in {col}; inspect it instead of counting it as zero.'
        out += active.astype('int64')
    return out
def _make_all_features(df):
    result = pd.DataFrame(index=df.index)
    # Normalize nullable pandas extension values before arithmetic and NumPy checks.
    tenure = pd.to_numeric(df.tenure, errors='raise').astype('float64')
    monthly = pd.to_numeric(df.MonthlyCharges, errors='coerce').astype('float64')
    total = pd.to_numeric(df.TotalCharges, errors='coerce').astype('float64')
    charge_month = np.divide(total.to_numpy(), tenure.to_numpy(), out=np.zeros(len(df),dtype=float), where=(tenure.to_numpy()!=0))
    charge_month[total.isna().to_numpy()] = np.nan
    result['charge_per_month'] = charge_month
    result['monthly_charge_x_tenure'] = monthly.to_numpy() * tenure.to_numpy()
    result['tenure_years'] = tenure.to_numpy() / 12
    result['num_services'] = _service_count(df)
    charge_service = np.divide(monthly.to_numpy(), result.num_services.to_numpy(), out=np.zeros(len(df),dtype=float), where=(result.num_services.to_numpy()!=0))
    charge_service[monthly.isna().to_numpy()] = np.nan
    result['charge_per_service'] = charge_service
    return result
def source_ready():
    global raw, train_df, validation_df, train_y, validation_y, train_features, validation_features, X_train, X_validation, prep, numeric, _raw_copy, _prepared_digest
    p=Path('telco_source.csv')
    if not p.exists(): raise FileNotFoundError('Missing telco_source.csv. Rerun C05 with the issued CSV and runtime ZIP.')
    assert hashlib.sha256(p.read_bytes()).hexdigest()==_SHA, 'Wrong or changed CSV. Upload the original issued telco_source.csv with its original name, then rerun C05.'
    raw=pd.read_csv(p,dtype={'TotalCharges':'string'}); _raw_copy=raw.copy(deep=True)
    groups=[set(_SPLIT['ids'][s]) for s in ['train','validation','final_test']]
    assert [len(s) for s in groups]==[4225,1409,1409]
    assert not any(groups[i]&groups[j] for i,j in [(0,1),(0,2),(1,2)])
    assert set.union(*groups)==set(raw.customerID)
    indexed=raw.set_index('customerID')
    train_df=indexed.loc[_SPLIT['ids']['train']].copy(); validation_df=indexed.loc[_SPLIT['ids']['validation']].copy()
    for d in [train_df,validation_df]: d['TotalCharges']=pd.to_numeric(d.TotalCharges.str.strip(),errors='coerce').astype('float64')
    train_y=train_df.Churn.copy(); validation_y=validation_df.Churn.copy()
    train_features=pd.concat([train_df[_BASE_NUM+_CAT],_make_all_features(train_df)],axis=1)
    validation_features=pd.concat([validation_df[_BASE_NUM+_CAT],_make_all_features(validation_df)],axis=1)
    numeric=_BASE_NUM+_EXTRA
    prep=ColumnTransformer([('num',Pipeline([('fill',SimpleImputer(strategy='median',keep_empty_features=True)),('scale',StandardScaler())]),numeric),('cat',Pipeline([('fill',SimpleImputer(strategy='most_frequent')),('onehot',OneHotEncoder(handle_unknown='ignore',sparse_output=False))]),_CAT)])
    a=prep.fit_transform(train_features); b=prep.transform(validation_features)
    names=list(prep.get_feature_names_out())
    X_train=pd.DataFrame(a,index=train_df.index,columns=names); X_validation=pd.DataFrame(b,index=validation_df.index,columns=names)
    _prepared_digest=working_digest()
    show_note('Workspace ready',f'Python {sys.version.split()[0]} · NumPy {np.__version__} · pandas {pd.__version__}\nSame C1 frozen split: train 4225 / validation 1409 / final test reserved 1409.\nAll: {len(names)} columns after one-hot (19 original predictors + five C3 formulas). Preprocessing fitted on train only.\nFinal test is neither inspected nor scored.')
    show_table('Your first five training customers','Read original values, the C3 service count and the known target. IDs are omitted.',train_features[['tenure','MonthlyCharges','TotalCharges','num_services']].assign(Churn=train_y).head(5).reset_index(drop=True))
def working_digest():
    h=hashlib.sha256()
    for value in [X_train,X_validation,train_y,validation_y,train_df,validation_df,train_features,validation_features]: h.update(pd.util.hash_pandas_object(value,index=True).values.tobytes())
    h.update(repr(list(X_train.columns)).encode()); h.update(repr(list(X_validation.columns)).encode())
    return h.hexdigest()
METHODS = ['Baseline', 'RandomOverSampler', 'SMOTE', 'class_weight']
METRICS = ['Accuracy', 'Precision', 'Recall', 'F1']
DEMO_FEATURES = ['cat__Contract_Month-to-month','num__tenure','num__charge_per_service','cat__TechSupport_No','cat__Contract_Two year','cat__OnlineSecurity_No','num__num_services','cat__InternetService_Fiber optic','cat__PaymentMethod_Electronic check','num__MonthlyCharges','num__TotalCharges','cat__OnlineBackup_No']
def current_guard():
    assert raw.equals(_raw_copy), 'Raw changed: restart C05.'
    assert hashlib.sha256(Path('telco_source.csv').read_bytes()).hexdigest() == _SHA, 'CSV changed: restore issued CSV.'
    assert working_digest() == _prepared_digest, 'Prepared train/validation changed: restart C05 and rerun downstream.'
    assert list(X_train.index) == _SPLIT['ids']['train']
    assert list(X_validation.index) == _SPLIT['ids']['validation']
    assert 'Churn' not in X_train and 'customerID' not in X_train
def config():
    current_guard()
    assert feature_mode in ['c4_personal', 'mentor_fallback'], 'Choose c4_personal or mentor_fallback in C05.'
    columns = personal_c4_columns if feature_mode == 'c4_personal' else DEMO_FEATURES
    assert isinstance(columns, list) and columns and len(set(columns)) == len(columns), 'C05 needs a nonempty unique list.'
    assert set(columns) <= set(X_train.columns), 'Unknown encoded C4 feature: copy exact names, not source labels.'
    return tuple(columns)
def function_stamp(fn):
    return hashlib.sha256(fn.__code__.co_code + repr((fn.__code__.co_consts, fn.__code__.co_names)).encode()).hexdigest()
def stamp():
    return (config(), feature_mode, function_stamp(metric_scores))
def check_metric_function():
    cases = [([1,1,1,1,0,0,0,0,0,0], [1,1,0,0,1,0,0,0,0,0]), ([1,0,1,0],[0,0,0,0]), ([1,0,0,1],[1,1,0,1])]
    for truth, predicted in cases:
        got = metric_scores(np.array(truth), np.array(predicted))
        expected = dict(zip(METRICS,[accuracy_score(truth,predicted),precision_score(truth,predicted,zero_division=0),recall_score(truth,predicted,zero_division=0),f1_score(truth,predicted,zero_division=0)]))
        assert set(got) == set(METRICS), 'Return Accuracy, Precision, Recall, F1.'
        np.testing.assert_allclose([got[k] for k in METRICS], [expected[k] for k in METRICS], err_msg='Check denominators and positive label 1. Use zero_division=0.')
    show_note('Metric check passed', 'Several cases agree with independent sklearn metrics. Your explanation still needs review.')
def check_threshold_function():
    for values in [np.array([.9,.45,.35,.2]), np.array([.3,.4,.5,.1,.7])]:
        for threshold in [.3,.4,.5]:
            np.testing.assert_array_equal(threshold_labels(values.copy(), threshold), (values >= threshold).astype(int), err_msg='Predict 1 when probability >= threshold, including equality.')
    show_note('Threshold check passed', 'Boundary values and three thresholds agree. No retraining occurred.')
def metric_row(method, threshold, truth, predicted):
    truth, predicted = np.asarray(truth), np.asarray(predicted)
    return dict(Method=method, Threshold=threshold, Found=int(((truth==1)&(predicted==1)).sum()), True_leavers=int((truth==1).sum()), Unnecessary_calls=int(((truth==0)&(predicted==1)).sum()), **metric_scores(truth, predicted))
def run_method(method):
    current_guard()
    assert method in METHODS
    train = X_train[list(config())].copy()
    target = train_y.copy()
    before = target.value_counts().to_dict()
    if method in ['RandomOverSampler', 'SMOTE']:
        sampler = RandomOverSampler(random_state=42) if method == 'RandomOverSampler' else SMOTE(random_state=42)
        train, target = sampler.fit_resample(train, target)  # TRAIN ONLY
    model = LogisticRegression(max_iter=1000, random_state=42, class_weight='balanced' if method == 'class_weight' else None)
    model.fit(train, target)
    probability = model.predict_proba(X_validation[list(config())])[:, list(model.classes_).index('Yes')]
    predicted = (model.predict(X_validation[list(config())]) == 'Yes').astype(int)
    truth = (validation_y == 'Yes').astype(int)
    show_note(method + ' · training counts', 'Before: ' + str(before) + '\nAfter: ' + str(pd.Series(target).value_counts().to_dict()))
    report = classification_report(truth, predicted, output_dict=True, zero_division=0)
    report_rows = [dict(Class=label, **values) for label, values in report.items() if isinstance(values, dict)]
    global last_classification_report
    last_classification_report = pd.DataFrame(report_rows)
    current_guard()
    return metric_row(method,.5,truth,predicted), probability
def record_method(method):
    global comparison, comparison_stamp, baseline_probability, baseline_stamp, threshold_stamp, leakage_stamp, facts_stamp
    current_guard()
    if method == 'Baseline':
        comparison = pd.DataFrame()
        baseline_probability = None
        baseline_stamp = threshold_stamp = leakage_stamp = facts_stamp = None
    else:
        assert baseline_stamp == stamp(), 'Run B04 baseline first.'
    row, probability = run_method(method)
    if method == 'Baseline':
        baseline_probability = probability.copy()
        baseline_stamp = stamp()
    comparison = pd.concat([comparison[comparison.Method != method] if not comparison.empty else comparison, pd.DataFrame([row])], ignore_index=True)
    comparison_stamp = stamp()
    show_table(method + ' · validation', 'People first: found leavers and unnecessary calls. Four metrics follow.', pd.DataFrame([row]))
    global last_check_card
    customer = validation_df.iloc[0]
    last_check_card = pd.DataFrame([{'Checking customer':'V01', 'Tenure (months)':customer['tenure'], 'Monthly bill':customer['MonthlyCharges'], 'Known outcome · check only':('Left' if customer['Churn']=='Yes' else 'Stayed'), 'Baseline score / 100':round(float(baseline_probability[0])*100,2), 'Current score / 100':round(float(probability[0])*100,2), 'Call at 50': 'Yes' if probability[0] >= .5 else 'No'}])
    show_table('V01 · same checking customer', 'Scores come from the fitted models. The known outcome is only for checking, never an input.', last_check_card)
    legend = '0 = Stayed; 1 = Left. Support = known cases of that class. Macro avg = average across classes; weighted avg = average weighted by class counts. Focus on row 1; reading the averages is optional.'
    display(HTML('<details><summary>Optional classification report · '+method+'</summary><p>'+legend+'</p>'+last_classification_report.to_html(index=False)+'</details>'))
    return row, probability

def compare_methods():
    assert_comparison()
    show_table('Four methods at cutoff .5', 'Same validation customers and features. Counts come before metrics.', comparison[comparison.Method.isin(METHODS)])

def threshold_sweep():
    global comparison, threshold_stamp, leakage_stamp, facts_stamp
    assert baseline_probability is not None and baseline_stamp == stamp(), 'Run B04 baseline first.'
    check_threshold_function()
    truth = (validation_y == 'Yes').astype(int)
    rows = [metric_row('Baseline threshold', t, truth, threshold_labels(baseline_probability,t)) for t in [.3,.4,.5]]
    comparison = pd.concat([comparison[comparison.Method != 'Baseline threshold'],pd.DataFrame(rows)],ignore_index=True)
    threshold_stamp = (stamp(), function_stamp(threshold_labels))
    leakage_stamp = facts_stamp = None
    show_table('Baseline threshold comparison', 'Same fitted baseline and validation scores; no retraining.',pd.DataFrame(rows))

def assert_thresholds():
    current_guard()
    assert baseline_stamp == stamp() and threshold_stamp == (stamp(), function_stamp(threshold_labels)), 'Missing/stale thresholds: rerun B04 and B05.'

def assert_comparison():
    current_guard()
    assert comparison_stamp == stamp() and set(comparison.Method).issuperset(METHODS), 'Run B04 and B06–B08 with current features.'
def leakage_inputs():
    current_guard()
    imputer = SimpleImputer(strategy='median')
    train = imputer.fit_transform(train_df[_BASE_NUM])
    validation = imputer.transform(validation_df[_BASE_NUM])
    return pd.DataFrame(train,columns=_BASE_NUM,index=train_df.index), pd.DataFrame(validation,columns=_BASE_NUM,index=validation_df.index)
def check_scaler_function():
    for train, validation in [(pd.DataFrame({'x':[0.,2.,4.],'z':[1.,1.,7.]}),pd.DataFrame({'x':[100.,200.],'z':[30.,40.]})), leakage_inputs()]:
        before = train.copy(deep=True)
        scaler = fit_train_scaler(train.copy(), validation.copy())
        expected = StandardScaler().fit(train)
        assert scaler.n_samples_seen_ == len(train), 'Fit must see train rows only; transform does not learn.'
        np.testing.assert_allclose(scaler.mean_,expected.mean_,err_msg='Scaler mean includes forbidden rows or wrong input.')
        np.testing.assert_allclose(scaler.scale_,expected.scale_)
        pd.testing.assert_frame_equal(train,before)
    show_note('Train-only scaler check passed', 'Both a deliberately shifted toy and Telco train statistics agree. Equal model scores cannot justify a wrong fit boundary.')
def _compare_scalers_details():
    global leakage_table, leakage_stamp, facts_stamp, threshold_stamp
    leakage_table = leakage_stamp = facts_stamp = None
    assert_thresholds()
    assert_comparison()
    check_scaler_function()
    train, validation = leakage_inputs()
    wrong = StandardScaler().fit(pd.concat([train,validation]))  # DECLARED WRONG
    correct = fit_train_scaler(train.copy(),validation.copy())
    leakage_table = pd.DataFrame({'Feature':train.columns,'Wrong mean (train+validation)':wrong.mean_,'Correct mean (train only)':correct.mean_,'Wrong scale':wrong.scale_,'Correct scale':correct.scale_,'Mean difference':wrong.mean_-correct.mean_})
    show_table('Wrong versus corrected numeric scaler', 'Same numeric inputs; only the scaler fit boundary differs.', leakage_table)
    show_note('Fit evidence', f'Wrong saw {wrong.n_samples_seen_} rows; corrected saw {correct.n_samples_seen_}.\nMaximum absolute validation transform difference: {np.max(np.abs(wrong.transform(validation)-correct.transform(validation))):.8f}.\nNo accuracy inflation is promised or required. Final test stays sealed.')
    truth = (validation_y == 'Yes').astype(int)
    result_rows = []
    predictions = []
    for name, scaler in [('Wrong train+validation scaler', wrong), ('Correct train-only scaler', correct)]:
        model = LogisticRegression(max_iter=1000, random_state=42)
        model.fit(scaler.transform(train), train_y)  # CLASSIFIER TRAIN ONLY in both variants
        predicted = (model.predict(scaler.transform(validation)) == 'Yes').astype(int)
        predictions.append(predicted)
        result_rows.append(metric_row(name,.5,truth,predicted))
    global leakage_metrics, leakage_prediction_disagreements
    leakage_metrics = pd.DataFrame(result_rows)
    leakage_prediction_disagreements = int(np.sum(predictions[0] != predictions[1]))
    show_table('Numeric models · wrong versus corrected fit', 'Both classifiers learn from train only; only the scaler learning boundary changes.', leakage_metrics)
    gap = leakage_metrics.iloc[0][METRICS].astype(float) - leakage_metrics.iloc[1][METRICS].astype(float)
    show_table('Wrong minus corrected metrics', 'Zero, positive and negative differences are all possible. A correct boundary is required even when scores are equal.', gap.rename_axis('Metric').reset_index(name='Wrong minus correct'))
    show_note('Prediction comparison', f'{leakage_prediction_disagreements} of {len(validation_y)} validation predictions differ. Final test is still sealed.')
    leakage_stamp = (stamp(), function_stamp(threshold_labels), function_stamp(fit_train_scaler))
def compare_scalers():
    # Run every audit; keep its dense tables available on request.
    from IPython.utils.capture import capture_output
    with capture_output() as audit:
        _compare_scalers_details()
    summary = pd.DataFrame([{'Fit': 'Wrong: training + checking', 'Rows': 5634},
                            {'Fit': 'Correct: training only', 'Rows': 4225}])
    show_table('Who taught the settings?', 'Use training rows only. Apply those settings to checking rows.', summary)
    if leakage_prediction_disagreements == 0:
        show_note('What happened in this run', 'Both versions made the same decisions. Checking people still must not teach the settings.')
    else:
        show_note('What happened in this run', f'The versions made different decisions for {leakage_prediction_disagreements} checking customers. Checking people must not teach the settings.')
    parts=[]
    for item in audit.outputs:
        data=item.data
        if 'text/html' in data: parts.append(data['text/html'])
        elif 'text/plain' in data:
            import html
            parts.append('<pre>'+html.escape(data['text/plain'])+'</pre>')
    display(HTML('<details><summary>Optional: full technical checks and metrics</summary>'+''.join(parts)+'</details>'))

def fresh_facts():
    global facts_stamp
    assert_thresholds()
    assert leakage_table is not None and leakage_stamp == (stamp(), function_stamp(threshold_labels), function_stamp(fit_train_scaler)), 'Rerun B09 after a repair or feature change.'
    matches = comparison[(comparison.Method == chosen_method) & (comparison.Threshold == chosen_threshold)]
    assert len(matches) == 1, 'Choose a measured method/threshold pair: four methods at 0.5 in B04/B06–B08, or Baseline threshold at 0.3/0.4/0.5 in B05.'
    show_table('Your current validation choice', 'Your selected option. Final test stays closed.', matches)
    display(HTML('<details><summary>Optional: customer details used</summary><p>' + feature_mode + ': ' + ', '.join(config()) + '</p></details>'))
    facts_stamp = (leakage_stamp,chosen_method,chosen_threshold)
def export_current():
    assert_thresholds()
    assert leakage_stamp == (stamp(), function_stamp(threshold_labels), function_stamp(fit_train_scaler)), 'Stale scaler evidence: rerun B09.'
    assert facts_stamp == (leakage_stamp,chosen_method,chosen_threshold), 'Choice changed: rerun B10, update H01 and export again.'
    assert written_notes_reviewed is True, 'Complete and manually review your explanations before acknowledging H02.'
    assert isinstance(recommendation,str) and recommendation.strip(), 'H01 is blank. Write your recommendation before export.'
    assert recommendation.strip() != 'WRITE YOUR RECOMMENDATION HERE', 'Replace the placeholder; no file was saved.'
    assert recommendation_choice == (chosen_method,chosen_threshold) and recommendation_feature_mode == feature_mode, 'Update H01 for the current choice/origin.'
    comparison.to_csv('M3C5_Comparison.csv',index=False)
    Path('M3C5_Recommendation.md').write_text(recommendation,encoding='utf-8')
    pd.testing.assert_frame_equal(pd.read_csv('M3C5_Comparison.csv'),comparison,check_exact=False)
    assert Path('M3C5_Recommendation.md').read_text(encoding='utf-8') == recommendation
    show_note('Two files exported and reopened', 'M3C5_Comparison.csv and M3C5_Recommendation.md match this run. This does not save your notebook or assess the meaning of your writing. Complete H03.')
    try:
        from google.colab import files
        files.download('M3C5_Comparison.csv')
        files.download('M3C5_Recommendation.md')
    except ImportError:
        print('Local files are beside this notebook.')
comparison = pd.DataFrame()
comparison_stamp = baseline_probability = baseline_stamp = leakage_table = leakage_stamp = facts_stamp = threshold_stamp = None
source_ready()
