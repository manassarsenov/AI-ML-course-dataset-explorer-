
import hashlib, json, time, sys, html
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display, HTML
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import mutual_info_classif, RFE
from sklearn.metrics import accuracy_score, f1_score
_SPLIT=json.loads(Path('_m3c4_runtime/M3_Split_Card.json').read_text(encoding='utf-8'))
_SHA='16320c9c1ec72448db59aa0a26a0b95401046bef5d02fd3aeb906448e3055e91'
_BASE_NUM=['SeniorCitizen','tenure','MonthlyCharges','TotalCharges']
_CAT=['gender','Partner','Dependents','PhoneService','MultipleLines','InternetService','OnlineSecurity','OnlineBackup','DeviceProtection','TechSupport','StreamingTV','StreamingMovies','Contract','PaperlessBilling','PaymentMethod']
_SERVICES=['PhoneService','InternetService','OnlineSecurity','OnlineBackup','DeviceProtection','TechSupport','StreamingTV','StreamingMovies']
_EXTRA=['charge_per_month','monthly_charge_x_tenure','tenure_years','num_services','charge_per_service']
def _service_count(df):
    out = pd.Series(0, index=df.index, dtype='int64')
    for col in _SERVICES:
        vals = df[col]
        if col == 'InternetService':
            allowed = {'DSL','Fiber optic','No'}
            found = set(vals.dropna().unique())
            assert found <= allowed, f'Unmapped InternetService value(s): {sorted(found-allowed)}'
            active = vals.isin(['DSL','Fiber optic'])
        else:
            allowed = {'Yes','No','No internet service','No phone service'}
            found = set(vals.dropna().unique())
            assert found <= allowed, f'Unmapped {col} value(s): {sorted(found-allowed)}'
            active = vals.eq('Yes')
        assert vals.notna().all(), f'Missing service value in {col}; inspect it instead of counting it as zero.'
        out += active.astype('int64')
    return out

def _make_all_features(df):
    result = pd.DataFrame(index=df.index)
    # Normalize nullable pandas extension values before arithmetic and NumPy checks.
    tenure = pd.to_numeric(df.tenure, errors='raise').astype('float64')
    monthly = pd.to_numeric(df.MonthlyCharges, errors='coerce').astype('float64')
    total = pd.to_numeric(df.TotalCharges, errors='coerce').astype('float64')
    charge_month = np.divide(total.to_numpy(), tenure.to_numpy(), out=np.zeros(len(df),dtype=float), where=(tenure.to_numpy()!=0))
    charge_month[total.isna().to_numpy()] = np.nan
    result['charge_per_month'] = charge_month
    result['monthly_charge_x_tenure'] = monthly.to_numpy() * tenure.to_numpy()
    result['tenure_years'] = tenure.to_numpy() / 12
    result['num_services'] = _service_count(df)
    charge_service = np.divide(monthly.to_numpy(), result.num_services.to_numpy(), out=np.zeros(len(df),dtype=float), where=(result.num_services.to_numpy()!=0))
    charge_service[monthly.isna().to_numpy()] = np.nan
    result['charge_per_service'] = charge_service
    return result
def show_note(title, text):
    display(HTML('<section style="margin:1.2rem 0;padding:1rem;border:1px solid currentColor;border-radius:8px;font:inherit;line-height:1.5">'
        + '<strong style="display:block;margin-bottom:.4rem">'+html.escape(title)+'</strong>'
        + '<div style="white-space:pre-wrap;overflow-wrap:anywhere">'+html.escape(str(text))+'</div></section>'))

def show_text(title, text):
    show_note(title, text)

def show_table(title, meaning, frame, rename=None, max_height=None):
    shown=frame.rename(columns=rename or {})
    table=shown.to_html(index=False,escape=True,max_rows=None,max_cols=None,border=0)
    table=table.replace('<table ', '<table style="border-collapse:collapse;width:100%;font:inherit;text-align:left" ')
    table=table.replace('<th>', '<th style="padding:.6rem;text-align:left !important;border-bottom:1px solid currentColor;white-space:normal">')
    table=table.replace('<td>', '<td style="padding:.6rem;text-align:left !important;vertical-align:top;border-bottom:1px solid currentColor;white-space:normal;overflow-wrap:anywhere;max-width:30rem">')
    panel_style='max-width:100%;overflow:auto'
    panel_label=''
    if max_height is not None:
        panel_style+=f';max-height:{max_height}px'
        panel_label='<p style="margin:.4rem 0;font-size:.9em">'+html.escape(f'Full table: {len(shown)} rows. Scroll inside the table to read every row; focus the panel to use the keyboard.')+'</p>'
    display(HTML('<section style="margin:1.5rem 0;font:inherit;line-height:1.5">'
        + '<h3 style="font:inherit;font-weight:700;margin:0 0 .4rem">'+html.escape(title)+'</h3>'
        + '<p style="margin:0 0 .8rem">'+html.escape(meaning)+'</p>'
        + panel_label+'<div role="region" tabindex="0" aria-label="'+html.escape(title,quote=True)+'" style="'+panel_style+'">'+table+'</div></section>'))

def source_ready():
    global raw, train_df, validation_df, train_y, validation_y, train_features, validation_features, X_train, X_validation, prep, numeric, _raw_copy, _prepared_digest
    p=Path('telco_source.csv')
    if not p.exists(): raise FileNotFoundError('Missing telco_source.csv. Rerun C01 with the issued CSV and runtime ZIP.')
    assert hashlib.sha256(p.read_bytes()).hexdigest()==_SHA, 'Wrong or changed CSV. Upload the original issued telco_source.csv with its original name, then rerun C01.'
    raw=pd.read_csv(p,dtype={'TotalCharges':'string'}); _raw_copy=raw.copy(deep=True)
    groups=[set(_SPLIT['ids'][s]) for s in ['train','validation','final_test']]
    assert [len(s) for s in groups]==[4225,1409,1409]
    assert not any(groups[i]&groups[j] for i,j in [(0,1),(0,2),(1,2)])
    assert set.union(*groups)==set(raw.customerID)
    indexed=raw.set_index('customerID')
    train_df=indexed.loc[_SPLIT['ids']['train']].copy(); validation_df=indexed.loc[_SPLIT['ids']['validation']].copy()
    for d in [train_df,validation_df]: d['TotalCharges']=pd.to_numeric(d.TotalCharges.str.strip(),errors='coerce').astype('float64')
    train_y=train_df.Churn.copy(); validation_y=validation_df.Churn.copy()
    train_features=pd.concat([train_df[_BASE_NUM+_CAT],_make_all_features(train_df)],axis=1)
    validation_features=pd.concat([validation_df[_BASE_NUM+_CAT],_make_all_features(validation_df)],axis=1)
    numeric=_BASE_NUM+_EXTRA
    prep=ColumnTransformer([('num',Pipeline([('fill',SimpleImputer(strategy='median',keep_empty_features=True)),('scale',StandardScaler())]),numeric),('cat',Pipeline([('fill',SimpleImputer(strategy='most_frequent')),('onehot',OneHotEncoder(handle_unknown='ignore',sparse_output=False))]),_CAT)])
    a=prep.fit_transform(train_features); b=prep.transform(validation_features)
    names=list(prep.get_feature_names_out())
    X_train=pd.DataFrame(a,index=train_df.index,columns=names); X_validation=pd.DataFrame(b,index=validation_df.index,columns=names)
    _prepared_digest=working_digest()
    show_note('Workspace ready',f'Python {sys.version.split()[0]} · NumPy {np.__version__} · pandas {pd.__version__}\nSame C1 frozen split: train 4225 / validation 1409 / final test reserved 1409.\nAll: {len(names)} columns after one-hot (19 original predictors + five C3 formulas). Preprocessing fitted on train only.\nFinal test is neither inspected nor scored.')
    show_table('Your first five training customers','Read original values, the C3 service count and the known target. IDs are omitted.',train_features[['tenure','MonthlyCharges','TotalCharges','num_services']].assign(Churn=train_y).head(5).reset_index(drop=True))
def working_digest():
    h=hashlib.sha256()
    for value in [X_train,X_validation,train_y,validation_y]: h.update(pd.util.hash_pandas_object(value,index=True).values.tobytes())
    h.update(repr(list(X_train.columns)).encode()); h.update(repr(list(X_validation.columns)).encode())
    return h.hexdigest()
source_ready()
def current_guard():
    assert raw.equals(_raw_copy) and hashlib.sha256(Path('telco_source.csv').read_bytes()).hexdigest()==_SHA, 'Raw changed'
    assert list(X_train.index)==_SPLIT['ids']['train'] and list(X_validation.index)==_SPLIT['ids']['validation'], 'Working rows changed'
    assert 'Churn' not in X_train and 'customerID' not in X_train
    assert X_train.columns.equals(X_validation.columns)
    assert working_digest()==_prepared_digest, 'Prepared matrices/targets changed; restore by rerunning from C01'
def rf_row(label, columns):
    current_guard()
    assert len(columns)>0 and len(set(columns))==len(columns)
    model=RandomForestClassifier(n_estimators=100,random_state=42)
    model.fit(X_train[columns],train_y); prediction=model.predict(X_validation[columns])
    return {'Feature Set':label,'Num Features':len(columns),'Accuracy':accuracy_score(validation_y,prediction),'F1':f1_score(validation_y,prediction,pos_label='Yes')}
def correlation_report():
    global corr,pairs,decisions,candidates
    corr=train_features[numeric].corr()
    show_note('1 · Train correlation heatmap','Look for strong positive or negative relationships between numeric columns. Correlation alone does not establish a cause or an exact duplicate.')
    fig,ax=plt.subplots(figsize=(9,7)); im=ax.imshow(corr,vmin=-1,vmax=1,cmap='coolwarm'); fig.colorbar(im,ax=ax)
    ax.set_xticks(range(len(numeric)),numeric,rotation=90); ax.set_yticks(range(len(numeric)),numeric); ax.set_title('Train numeric correlation before one-hot'); plt.tight_layout(); plt.show()
    pairs=pd.DataFrame([(a,b,float(corr.loc[a,b])) for i,a in enumerate(numeric) for b in numeric[i+1:] if abs(corr.loc[a,b])>0.85],columns=['A','B','r'])
    # Keep earlier, simpler source fields. Process all pairs, including already-covered pairs.
    removed=set(); records=[]
    for row in pairs.itertuples(index=False):
        if row.A in removed or row.B in removed:
            records.append((row.A,row.B,'already covered','A member was already removed; no extra removal'))
        else:
            removed.add(row.B); records.append((row.A,row.B,row.B,'Keep earlier source/formula in declared order for interpretability'))
    decisions=pd.DataFrame(records,columns=['A','B','Removed','Reason'])
    candidates=[c for c in X_train if c not in {'num__'+x for x in removed}]
    names={'A':'Feature A','B':'Feature B','r':'Correlation r','Removed':'Removed feature'}
    show_table('2 · Pairs above the threshold','Only pairs with abs(r) > 0.85 appear here. Similar movement does not make every pair identical.',pairs,names)
    show_table('3 · Keep or remove: the prepared rule','Keep the earlier field in the declared order. Already covered means a previous removal resolved this pair.',decisions,names)
    show_note('Correlation summary',f'All: {X_train.shape[1]} columns preserved for the baseline. Candidates: {len(candidates)} columns continue to MI and RFE. No rows were removed.')
def mi_ranking():
    global mi_scores,discrete_mask
    discrete_mask=np.array([c.startswith('cat__') or c in ['num__SeniorCitizen','num__num_services'] for c in candidates])
    mi_input=X_train[candidates].copy()
    # Scaling preserves integer-count categories but turns them into floats.
    # Encode their distinct train values as integers for discrete MI explicitly.
    for column in np.array(candidates)[discrete_mask]: mi_input[column]=pd.factorize(mi_input[column],sort=True)[0]
    mi_scores=pd.Series(mutual_info_classif(mi_input,train_y,discrete_features=discrete_mask,random_state=42),index=candidates).sort_values(ascending=False,kind='stable')
    show_note('MI settings · train only','Discrete columns: '+', '.join(np.array(candidates)[discrete_mask]))
    show_table('Train MI ranking','Higher MI means more information about Churn in training data; it does not guarantee the best combination.',mi_scores.rename_axis('Feature').reset_index(name='Train MI'),max_height=420)
    show_note('MI chart','Read the ranking, then choose your own top_k before seeing validation results.')
    mi_scores.iloc[::-1].plot.barh(figsize=(9,10),title='Train MI ranking after correlation filter'); plt.tight_layout(); plt.show()
def selection_signature():
    assert isinstance(top_k,int) and not isinstance(top_k,bool) and 1<=top_k<=len(candidates), 'Set top_k to a valid integer in C09'
    assert isinstance(selection_reason,str) and selection_reason.strip(), 'Write your own reason before validation'
    return (top_k,selection_reason,tuple(mi_scores.index[:top_k]))
def chosen_columns(): return list(selection_signature()[2])
def function_signature():
    code=compare_all_mi.__code__
    return hashlib.sha256(code.co_code+repr((code.co_consts,code.co_names,code.co_varnames)).encode()).hexdigest()
def validate_compare():
    global comparison,comparison_stamp,results,result_stamp,rfe_columns,rfe_stamp
    # Invalidate old results BEFORE invoking any student code.
    comparison=results=None; comparison_stamp=result_stamp=rfe_stamp=None; rfe_columns=None
    sig=selection_signature(); current_guard()
    expected=pd.DataFrame([rf_row('all',list(X_train)),rf_row('MI',chosen_columns())])
    got=compare_all_mi(X_train.copy(),X_validation.copy(),train_y.copy(),validation_y.copy(),chosen_columns())
    assert isinstance(got,pd.DataFrame), 'Return a pandas DataFrame'
    pd.testing.assert_frame_equal(got.reset_index(drop=True),expected,check_dtype=False,atol=1e-12,rtol=1e-12)
    comparison=expected; comparison_stamp=(sig,function_signature()); show_table('Validation · all versus MI','Same training setup and validation customers; only the input columns differ. RFE joins later in C15.',comparison)
def assert_comparison():
    current_guard(); assert comparison is not None and comparison_stamp==(selection_signature(),function_signature()), 'Missing/stale C12: rerun C12, C14, C15 after a change'
def run_rfe():
    global rfe_columns,rfe_stamp,rfe_seconds,rfe_support,results,result_stamp
    results=None; result_stamp=None; rfe_columns=None; rfe_stamp=None
    assert_comparison(); start=time.perf_counter()
    selector=RFE(RandomForestClassifier(n_estimators=100,random_state=42),n_features_to_select=max(1,len(candidates)//2),step=1)
    selector.fit(X_train[candidates],train_y)
    rfe_seconds=time.perf_counter()-start
    rfe_columns=list(np.array(candidates)[selector.support_]); rfe_support=pd.DataFrame({'Feature':candidates,'Selected':selector.support_,'Rank':selector.ranking_})
    rfe_stamp=(comparison_stamp,tuple(rfe_columns))
    show_table('RFE · selected columns and ranks','Selected=True means kept. Rank=1 identifies the kept set; higher ranks were removed earlier.',rfe_support,max_height=420)
    show_note('RFE summary',f'Kept {len(rfe_columns)} of {len(candidates)} candidates. Runtime: {rfe_seconds:.2f} seconds.\nMI ∩ RFE: '+', '.join(sorted(set(chosen_columns())&set(rfe_columns))))
def final_table():
    global results,result_stamp
    results=None; result_stamp=None; assert_comparison()
    assert rfe_columns is not None and rfe_stamp==(comparison_stamp,tuple(rfe_columns)), 'Rerun C14'
    results=pd.concat([comparison,pd.DataFrame([rf_row('RFE',rfe_columns)])],ignore_index=True)
    result_stamp=comparison_stamp; show_table('Validation · all, MI and RFE','Compare feature count, Accuracy and F1 together. Every row uses the same 1409 validation customers.',results)
    counts='; '.join(f'{row[0]}: {round(row[2]*1409)} correct / 1409' for row in results.itertuples(index=False,name=None))
    show_note('Read the size of the difference',counts+'\nLargest Accuracy gap: '+str(round((results.Accuracy.max()-results.Accuracy.min())*1409))+' customer predictions. F1 also matters; importance does not establish a cause.')
def fresh_results():
    assert_comparison(); assert results is not None and result_stamp==comparison_stamp and rfe_columns is not None and rfe_stamp==(comparison_stamp,tuple(rfe_columns)), 'Stale/missing final result; rerun C12, C14, C15'
def handoff_context():
    fresh_results()
    show_table('Handoff · current results only','These are facts from the current run, not proof of native rules or your own analysis.',results)
    show_text('Handoff · protected context','MI columns: '+', '.join(chosen_columns())+'\nRaw SHA: '+_SHA+'\nFrozen split 4225/1409/1409. Final test untouched. Native rules and own written analysis are NOT VERIFIED by this code.')
def save_current():
    fresh_results()
    expected=pd.concat([pd.DataFrame([rf_row('all',list(X_train)),rf_row('MI',chosen_columns())]),pd.DataFrame([rf_row('RFE',rfe_columns)])],ignore_index=True)
    pd.testing.assert_frame_equal(results,expected)
    payload={'source_sha256':_SHA,'split_counts':[4225,1409,1409],'top_k':top_k,'selection_reason':selection_reason,'MI':chosen_columns(),'RFE':rfe_columns,'results':results.to_dict('records'),'native_rules':'NOT VERIFIED','own_analysis':'MANUAL REVIEW REQUIRED'}
    path=Path('M3C4_Current_Result.json'); path.write_text(json.dumps(payload,indent=2),encoding='utf-8')
    reopened=json.loads(path.read_text(encoding='utf-8')); assert reopened==payload
    show_note('Current result saved and reopened','M3C4_Current_Result.json matches the current run. It is a temporary result; save your executed notebook in C20. Your own writing and native rules still need manual review.')
    try:
        from google.colab import files
        files.download(str(path))
    except ImportError: print(path.resolve())
comparison=results=rfe_columns=None
comparison_stamp=result_stamp=rfe_stamp=None
